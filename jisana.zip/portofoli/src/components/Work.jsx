import React from 'react'

function Work() {
  return (
    <div>Work</div> 
  )
}

const Work = () => {
  return (
    <div name='work' className='w-full md:h-screen text-gray-300 bg-[#0a192f]'>
      <div className='max-w-[1000px] mx-auto p-4 flex flex-col justify-center w-full h-full'>
        <div className='pb-8 w-full flex justify-center items-center flex-col'>
          <p className='text-4xl font-bold inline border-b-4 text-gray-300 border-cyan-500'>Work</p>
          <p className='py-6 text-2xl'>Check out some of my most recent work</p>
        </div>

        <div className='grid sm:grid-cols-2 md:grid-cols-3 gap-4'>
          {/* Hospital Tracker App without image */}
          <div className='bg-[#1a1a1a] shadow-lg shadow-[#040c16] group container rounded-md flex justify-center items-center mx-auto content-div h-64'>
            <div className='opacity-100 flex justify-center items-center flex-col text-center px-4'>
              <span className='text-lg font-bold text-white tracking-wider'>Hospital Tracker App</span>
              <p className='text-sm text-white'>Real-time availability of doctors and hospitals during emergencies</p>
              <div className='pt-4'>
                <a href='https://example.com/demo' target='_blank' rel='noopener noreferrer'>
                  <button className='text-center rounded-lg px-4 py-2 m-2 bg-white text-gray-700 font-bold text-sm'>Demo</button>
                </a>
                <a href='https://github.com/Jisanas/hospital-tracker' target='_blank' rel='noopener noreferrer'>
                  <button className='text-center rounded-lg px-4 py-2 m-2 bg-white text-gray-700 font-bold text-sm'>Code</button>
                </a>
              </div>
            </div>
          </div>

          {/* Placeholder black cards */}
          {[1, 2, 3, 4, 5].map((item) => (
            <div
              key={item}
              className='shadow-lg shadow-[#040c16] group container rounded-md flex justify-center items-center mx-auto content-div h-64 bg-[#1a1a1a]'
            >
              <div className='text-center'>
                <span className='text-lg font-bold text-white tracking-wider'>Coming Soon</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};


export default Experience;



