import React, { useState } from 'react';
import {
  FaBars,
  FaTimes,
  FaGithub,
  FaInstagram,
} from 'react-icons/fa';
import { HiOutlineMail } from 'react-icons/hi';
import { Link } from 'react-scroll';

const Navbar = () => {
  const [nav, setNav] = useState(false);
  const handleClick = () => setNav(!nav);

  return (
    <div className='fixed w-full h-20 flex justify-between items-center px-4 bg-[#0a192f] text-gray-300 z-50'>
      <div>
        <h1 className='text-2xl italic font-serif font-light'>Jisana S</h1>
      </div>

      <ul className='hidden md:flex gap-x-8'>
        {['home', 'about', 'skills', 'experience', 'work', 'contact'].map((section) => (
          <li key={section} className='capitalize cursor-pointer hover:text-cyan-400'>
            <Link to={section} smooth={true} duration={500}>
              {section}
            </Link>
          </li>
        ))}
      </ul>

      <div onClick={handleClick} className='md:hidden z-10 cursor-pointer'>
        {!nav ? <FaBars /> : <FaTimes />}
      </div>

      {/* Mobile menu */}
      <ul className={!nav ? 'hidden' : 'absolute top-0 left-0 w-full h-screen bg-[#0a192f] flex flex-col justify-center items-center'}>
        {['home', 'about', 'skills', 'experience', 'work', 'contact'].map((section) => (
          <li key={section} className='py-6 text-4xl'>
            <Link onClick={handleClick} to={section} smooth={true} duration={500}>
              {section}
            </Link>
          </li>
        ))}
      </ul>

      {/* Social icons */}
      <div className='hidden lg:flex fixed flex-col top-[35%] left-0'>
        <ul>
          <li className='w-40 h-14 flex justify-between items-center ml-[-100px] hover:ml-[-10px] duration-300 bg-pink-600'>
            <a href='https://instagram.com/itsmijisanazz' className='flex justify-between items-center w-full text-gray-300 px-4' target='_blank' rel='noopener noreferrer'>
              Instagram <FaInstagram size={30} />
            </a>
          </li>
          <li className='w-40 h-14 flex justify-between items-center ml-[-100px] hover:ml-[-10px] duration-300 bg-[#333333]'>
            <a href='https://github.com/Jisanas' className='flex justify-between items-center w-full text-gray-300 px-4' target='_blank' rel='noopener noreferrer'>
              GitHub <FaGithub size={30} />
            </a>
          </li>
          <li className='w-40 h-14 flex justify-between items-center ml-[-100px] hover:ml-[-10px] duration-300 bg-[#6fc2b0]'>
            <a href='mailto:jisana532008@gmail.com' className='flex justify-between items-center w-full text-gray-300 px-4'>
              Email <HiOutlineMail size={30} />
            </a>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Navbar;
