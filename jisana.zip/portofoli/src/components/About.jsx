import React from 'react';

const About = () => {
  return (
    <div name="about" className="w-full bg-[#0a192f] text-gray-300 py-16">
      <div className="max-w-5xl mx-auto px-4">
        <h2 className="text-4xl font-bold border-b-4 border-cyan-500 mb-6">About Me</h2>
        <p className="text-lg mb-4">
          Hi, I’m <strong>Jisana S</strong>, a frontend and backend developer who builds accessible,
          pixel-perfect web experiences. I specialize in creating intuitive interfaces using React,
          JavaScript, HTML, and CSS.
        </p>
        <p className="text-lg mb-4">
          I’m currently pursuing +2 Computer Science at CPHSS Kuttikadu. My web development journey started
          in 10th standard by customizing simple web pages using HTML and CSS. Since then, I’ve grown a strong
          interest in frontend development and enjoy making user-friendly, visually appealing websites.
        </p>
        <p className="text-lg">
          When I’m not optimizing UI performance, I love exploring mobile development with React Native and
          challenging myself with new projects to enhance my skills.
        </p>
      </div>
    </div>
  );
};

export default About;




