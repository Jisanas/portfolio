import React from 'react';

const Experience = () => {
  return (
    <div name="experience" className="w-full bg-[#0a192f] text-gray-300 py-16">
      <div className="max-w-5xl mx-auto px-4 text-center">
        <h2 className="text-4xl font-bold border-b-4 border-cyan-500 inline-block mb-4">Experience</h2>
        <p className="text-lg mb-10">
          Here are some of the experiences and projects I've worked on.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-[#112240] shadow-md shadow-black p-6 rounded hover:scale-105 duration-500">
            <h3 className="text-xl font-semibold mb-2">Emergency Doctor Availability Tracker</h3>
            <p className="text-sm">
              A web application to track the availability of doctors in case of emergencies. Built with React and Firebase.
            </p>
          </div>
          <div className="bg-[#112240] shadow-md shadow-black p-6 rounded hover:scale-105 duration-500">
            <h3 className="text-xl font-semibold mb-2">Portfolio Website</h3>
            <p className="text-sm">
              Designed and developed a responsive personal portfolio website using React, Tailwind CSS and modern UI practices.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};


export default Experience;
