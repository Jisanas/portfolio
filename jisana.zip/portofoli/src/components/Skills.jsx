import React from 'react';

const Skills = () => {
  const skills = ['HTML', 'CSS', 'JAVASCRIPT', 'REACT', 'GITHUB', 'NODE JS', 'MONGO DB', 'AWS', 'Django', 'Sass', 'Mongodb', 'GraphQL'];

  return (
    <div name="skills" className="w-full bg-[#0a192f] text-gray-300 py-16">
      <div className="max-w-5xl mx-auto px-4 text-center">
        <h2 className="text-4xl font-bold border-b-4 border-cyan-500 inline-block mb-4">Skills</h2>
        <p className="text-lg mb-10">
          I enjoy diving into and learning new things. Here's a list of technologies I've worked with:
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {skills.map((skill, index) => (
            <div
              key={index}
              className="bg-[#112240] shadow-md shadow-black hover:scale-105 duration-500 py-4 rounded text-center"
            >
              {skill}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Skills;
