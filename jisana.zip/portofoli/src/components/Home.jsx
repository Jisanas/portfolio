import React from 'react'

function Home() {
  return (
    <div>Home</div> 
  )
}
<div
  name="home"
  className="h-screen w-full bg-cover bg-center"
  style={{ backgroundImage: "url('../assets/background.png')" }}
>
  <div className="max-w-screen-lg mx-auto flex flex-col items-center justify-center h-full px-4 md:flex-row">
    <div className="text-center md:text-left">
      <h1 className="text-4xl sm:text-7xl font-bold text-white">
        Hi, I’m <span className="text-cyan-400">Jisana S</span>
      </h1>
      <p className="text-gray-300 py-4 max-w-md">
        A frontend and backend developer building pixel-perfect UIs.
      </p>
    </div>
    <div>
      <img src="me.png" alt="profile" className="rounded-2xl w-2/3 mx-auto border-4 border-white" />
    </div>
  </div>
</div>

export default Home;
