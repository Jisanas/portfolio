import React from 'react'

function Contact() {
  return (
    <div>Contact</div> 
  )
}
//Contact.jsx
import React from 'react'

import React from 'react';
import { FaInstagram, FaGithub, FaEnvelope } from 'react-icons/fa';

const Contact = () => {
  return (
    <div name="contact" className="w-full bg-[#0a192f] text-gray-300 py-16">
      <div className="max-w-4xl mx-auto px-4 text-center">
        <h2 className="text-4xl font-bold inline border-b-4 border-cyan-500 mb-4">Contact</h2>
        <p className="text-lg mb-8">Feel free to reach out or connect with me!</p>

        <div className="flex justify-center gap-10 text-3xl">
          <a
            href="https://instagram.com/itsmijisanazz"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-cyan-500 transition-colors duration-300"
          >
            <FaInstagram />
          </a>
          <a
            href="https://github.com/Jisanas"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-cyan-500 transition-colors duration-300"
          >
            <FaGithub />
          </a>
          <a
            href="mailto:jisana532008@gmaiol.com"
            className="hover:text-cyan-500 transition-colors duration-300"
          >
            <FaEnvelope />
          </a>
        </div>
      </div>
    </div>
  );
};



export default Contact
